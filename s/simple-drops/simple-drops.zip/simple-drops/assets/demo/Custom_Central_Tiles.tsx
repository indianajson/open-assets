<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="Custom_Central_Tiles" tilewidth="64" tileheight="40" tilecount="8" columns="2">
 <tileoffset x="0" y="8"/>
 <image source="Custom_Central_Tiles.png" width="128" height="160"/>
</tileset>
