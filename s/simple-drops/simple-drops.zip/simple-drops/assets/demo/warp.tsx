<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="warp" tilewidth="61" tileheight="32" tilecount="6" columns="6" objectalignment="top">
 <tileoffset x="1" y="0"/>
 <grid orientation="isometric" width="62" height="32"/>
 <image source="warp.png" width="366" height="32"/>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4.96774" y="5.87097" width="19.5161" height="19.6452"/>
  </objectgroup>
  <animation>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
  </animation>
 </tile>
</tileset>
