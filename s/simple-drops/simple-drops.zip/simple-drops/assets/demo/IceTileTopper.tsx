<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="IceTileTopper" tilewidth="64" tileheight="32" tilecount="12" columns="3" objectalignment="top">
 <image source="IceTileTopper.png" width="192" height="128"/>
 <tile id="0" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="1" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="2" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="3" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="4" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="5" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="6" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="7" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="8" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="9" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="10" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
 <tile id="11" type="Ice">
  <properties>
   <property name="Sound Effect" value="/server/IceSlide.ogg"/>
  </properties>
 </tile>
</tileset>
